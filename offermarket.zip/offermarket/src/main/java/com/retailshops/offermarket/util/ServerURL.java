/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.retailshops.offermarket.util;

/**
 *
 * @author sarathraj
 */
public class ServerURL {
   public static String dataURL  = "http://192.168.0.21:8083/uploads/"; 
}
