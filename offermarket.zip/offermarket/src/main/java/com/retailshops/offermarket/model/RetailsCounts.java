/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.retailshops.offermarket.model;

/**
 *
 * @author sarathraj
 */
public class RetailsCounts {
   private String outletscount;
        private String    offercount;
        private String    salescount;
        private String    userscount;

    public String getOutletscount() {
        return outletscount;
    }

    public void setOutletscount(String outletscount) {
        this.outletscount = outletscount;
    }

    public String getOffercount() {
        return offercount;
    }

    public void setOffercount(String offercount) {
        this.offercount = offercount;
    }

    public String getSalescount() {
        return salescount;
    }

    public void setSalescount(String salescount) {
        this.salescount = salescount;
    }

    public String getUserscount() {
        return userscount;
    }

    public void setUserscount(String userscount) {
        this.userscount = userscount;
    }
        
        
        
}
